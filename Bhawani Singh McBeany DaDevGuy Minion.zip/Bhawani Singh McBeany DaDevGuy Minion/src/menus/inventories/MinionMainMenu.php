<?php

declare(strict_types=1);

namespace Mcbeany\BetterMinion\menus\inventories;

use Mcbeany\BetterMinion\BetterMinion;
use Mcbeany\BetterMinion\entities\BaseMinion;
use Mcbeany\BetterMinion\menus\InventoryMenu;
use Mcbeany\BetterMinion\menus\MinionMenuTrait;
use Mcbeany\BetterMinion\utils\Language;
use Mcbeany\BetterMinion\utils\Utils;
use muqsit\invmenu\type\InvMenuTypeIds;
use pocketmine\block\BlockFactory;
use pocketmine\block\BlockLegacyIds;
use pocketmine\block\utils\DyeColor;
use pocketmine\block\VanillaBlocks;
use onebone\economyapi\EconomyAPI;
use pocketmine\item\VanillaItems;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\item\ItemIds;
use pocketmine\player\Player;
use function array_fill;
use function array_map;
use function array_search;
use function floor;
use function in_array;
use function range;

class MinionMainMenu extends InventoryMenu{
	use MinionMenuTrait {
		__construct as private __constructMinionMenu;
	}

	protected const TYPE = InvMenuTypeIds::TYPE_DOUBLE_CHEST;

	protected bool $readonly = true;
	private array $invSlots;

	public function __construct(?BaseMinion $minion = null){
		parent::__construct();
		$this->name = $minion?->getOriginalNameTag() ?? "";
		$this->invSlots = array_map(fn (int $i) => (int) (21 + ($i % 5) + (9 * (floor($i / 5)))), range(0, BaseMinion::MAX_LEVEL));
		$this->__constructMinionMenu($minion);
	}

	public function render() : void{
		$inv = $this->getInvMenu()->getInventory();
        $this->getInvMenu()->setName("§l§cMINION INVENTORY");
		$inv->setContents(array_fill(0, 54, ItemFactory::getInstance()->get(ItemIds::STAINED_GLASS_PANE, 15)->setCustomName("§k")));
        
		foreach($this->invSlots as $i => $slot){
			$invItem = $this->getMinion()->getMinionInventory()->slotExists($i) ?
				$this->getMinion()->getMinionInventory()->getItem($i) :
				VanillaBlocks::INVISIBLE_BEDROCK()->asItem()->setCustomName("§r§6Unlock At Level §9" . Utils::getRomanNumeral($i + 1));
			$inv->setItem($slot, $invItem);
		}
		$info_item = VanillaItems::PLAYER_HEAD()->setCustomName($this->getMinion()->getOriginalNameTag());
		$info_item->setLore([
			"§r§eTier: §f" . Utils::getRomanNumeral($this->getMinion()->getMinionInfo()->getLevel()),
			"§r§eCollected Resources: §f" . $this->getMinion()->getMinionInfo()->getCollectedResources(),
		]);
		$inv->setItem(45, $info_item);
		$inv->setItem(48, VanillaBlocks::CHEST()->asItem()->setCustomName("§r§l§eCOLLECT ITEMS\n\n§r§7Click To Collect All Items\n§r§7From Minion Inventory To Your\n§r§7Inventory.\n\n§r§l§aClick To Collect"));
		$inv->setItem(50, VanillaItems::NETHER_STAR()->setCustomName("§r§l§eUPGRADE MINION\n\n§r§7Click To Upgrade Your Minion\n§r§7To Next Level For Unlock More\n§r§7Inventory Slots.\n\n§r§l§aClick To Upgrade\n\n§r§cPrice§7: §92000"));
		$inv->setItem(52, VanillaBlocks::BEDROCK()->asItem()->setCustomName("§r§l§ePICKUP MINION\n\n§r§7Click To Pickup Your Minion In\n§r§7Your Inventory For Place In\n§r§7Different Location.\n\n§r§l§aClick To Pickup"));
	}

	public function onResponse(Player $player, $response){
		$this->getMinion()->continueWorking();
		$slot = $response->getAction()->getSlot();
		switch($slot){
			case 48:
				$player->sendMessage(Language::retrieved_all_results());
				for($i = 0; $i < $this->getMinion()->getMinionInventory()->getSize(); $i++){
					if(!$this->getMinion()->takeStuff($i, $player)){
						break;
					}
				}
				$this->onUpdate();
				break;
			case 52:
				$info = $this->getMinion()->getMinionInfo();
				$spawner = BetterMinion::getInstance()->createSpawner(
					$info->getType(),
					$info->getTarget(),
					$info->getLevel(),
					$info->getMoneyHeld(),
					$info->getCollectedResources()
				);
				if($player->getInventory()->canAddItem($spawner)){
					$this->getMinion()->flagForDespawn();
					$player->getInventory()->addItem($spawner);
				}else{
					$player->sendMessage(Language::inventory_is_full());
				}
				$this->forceClose($player);
				break;
			case 50:
  if(EconomyAPI::getInstance()->myMoney($player) < 2000){
                $player->sendMessage("§7(§a!§7) §cYou Don't Have Enough Money To Level UP Your Minion");
      $this->forceClose($player);
      } else {
      EconomyAPI::getInstance()->reduceMoney($player, 2000);
    $this->getMinion()->levelUp();
      $player->sendMessage("§7(§a!§7) §r§aSuccessfully Level Up Your Minion To Next Level");
      $this->forceClose($player);
                $this->onUpdate();
      }
				break;
			default:
				if(in_array($slot, $this->invSlots, true)){
					if(!$this->getMinion()->takeStuff(array_search($slot, $this->invSlots, true), $player)){
						$player->sendMessage(Language::inventory_is_full());
					}
					$this->onUpdate();
				}
				break;
		}
		$this->getMinion()->continueWorking();
	}

	public function onClose(Player $player) : void{
		$this->getMinion()->removeMenu($this);
	}

	public function display(Player $player) : void{
		parent::display($player);
		$this->getMinion()->registerMenu($this);
	}

	public function onUpdate() : void{
		$this->render();
	}

}
